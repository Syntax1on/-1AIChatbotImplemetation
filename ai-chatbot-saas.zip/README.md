# AI Chatbot SaaS

This is a Dockerized AI chatbot SaaS starter with GPT-4o, LangChain, PostgreSQL, and ChromaDB.

## Stack
- Next.js 14 (Frontend)
- Node.js (Backend API)
- GPT-4o + LangChain (AI)
- PostgreSQL (DB)
- ChromaDB (Vector DB)
- Docker (Deployment)

## Setup
1. Add your OpenAI key to `.env`
2. Run `docker-compose up --build`
